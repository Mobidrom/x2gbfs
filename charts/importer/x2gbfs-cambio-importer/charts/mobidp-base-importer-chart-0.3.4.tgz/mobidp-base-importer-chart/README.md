# mobidp-base-importer-chart

![Version: 0.3.4](https://img.shields.io/badge/Version-0.3.2-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

A base Helm chart for importer and importer-steps based on CronWorkflows and WorkflowTemplates respectively

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| John Funk | <john.funk@mobidrom.nrw> |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| global.imagePullSecrets | list | `[{"name":"mobidrom-registry"}]` | Credentials to pull image from registry. Default allows pulling images from Mobidrom's GitHub registry. |
| global.serviceAccountName | string | `"wrkflw-run-tls-pods-sa"` | Only override if another ServiceAccount is available that has sufficient permissions to read certificates in the cluster |
| importer | object | `{"concurrencyPolicy":"","enabled":false,"labels":{},"metadata":{"destination":"","frequency":"","source":""},"name":"","schedule":"","steps":{"extract":[{"config":[{"name":"","value":""}],"name":""}],"load":[{"config":[{"name":"","value":""}],"name":""}],"transform":[{"config":[{"name":"","value":""}],"name":""}]}}` | All required importer attributes can be omitted, if 'importer.enabled: false' |
| importer.concurrencyPolicy | string | `""` | Optional; defaults to 'Forbid' |
| importer.enabled | bool | `false` | Enable/disable creation of an importer. Defaults to 'false' |
| importer.labels | object | `{}` | Optional; additional labels to merge with default app.kubernetes.io labels |
| importer.metadata | object | `{"destination":"","frequency":"","source":""}` | REQUIRED; Human-readable importer description |
| importer.metadata.destination | string | `""` | REQUIRED; Specify data target, eg KStore |
| importer.metadata.frequency | string | `""` | REQUIRED; Specify human-readable schedule format |
| importer.metadata.source | string | `""` | REQUIRED; Specify data source |
| importer.name | string | `""` | REQUIRED; Importer name |
| importer.schedule | string | `""` | REQUIRED; Specify how often the importer should run using cron syntax |
| importer.steps | object | `{"extract":[{"config":[{"name":"","value":""}],"name":""}],"load":[{"config":[{"name":"","value":""}],"name":""}],"transform":[{"config":[{"name":"","value":""}],"name":""}]}` | REQUIRED; Define the ETL steps to run for the specific importer. |
| importer.steps.extract | list | `[{"config":[{"name":"","value":""}],"name":""}]` | Within the 'extract' section, all steps run in parallel. |
| importer.steps.extract[0] | object | `{"config":[{"name":"","value":""}],"name":""}` | REQUIRED; Name of the extractor (should equal <extractor-name> in `kubernetes/kubectl/extractor/<extractor-name>`) |
| importer.steps.extract[0].config | list | `[{"name":"","value":""}]` | REQUIRED; Provide configuration like the URL to extract data from |
| importer.steps.extract[0].config[0] | object | `{"name":"","value":""}` | REQUIRED; Name of the environment variable |
| importer.steps.extract[0].config[0].value | string | `""` | REQUIRED; Value of the environment variable |
| importer.steps.load | list | `[{"config":[{"name":"","value":""}],"name":""}]` | The workflow proceeds to the next outer list item only after all steps in the current inner list complete. |
| importer.steps.load[0] | object | `{"config":[{"name":"","value":""}],"name":""}` | REQUIRED; Name of the loader (should equal <loader-name> in `kubernetes/kubectl/loader/<loader-name>`) |
| importer.steps.load[0].config | list | `[{"name":"","value":""}]` | REQUIRED; Provide configuration like the filename that needs to be fetched from S3 |
| importer.steps.load[0].config[0] | object | `{"name":"","value":""}` | REQUIRED; Name of the environment variable |
| importer.steps.load[0].config[0].value | string | `""` | REQUIRED; Value of the environment variable |
| importer.steps.transform | list | `[{"config":[{"name":"","value":""}],"name":""}]` | The workflow proceeds to the next outer list item only after all steps in the current inner list complete. |
| importer.steps.transform[0] | object | `{"config":[{"name":"","value":""}],"name":""}` | REQUIRED; Name of the transformer (should equal <transformer-name> in `kubernetes/kubectl/transformer/<transformer-name>`) |
| importer.steps.transform[0].config | list | `[{"name":"","value":""}]` | REQUIRED; Provide list of configuration like the filename that needs to be fetched from the Object Store |
| importer.steps.transform[0].config[0] | object | `{"name":"","value":""}` | REQUIRED; Name of the environment variable |
| importer.steps.transform[0].config[0].value | string | `""` | REQUIRED; Value of the environment variable |
| importerStep | object | `{"args":[],"command":["sh","-c"],"extractor":{"enabled":false},"image":{"name":"","registry":"ghrc.io","repository":"","tag":""},"labels":{},"loader":{"enabled":false},"name":"","transformer":{"enabled":false},"ttlStrategy":{"secondsAfterFailure":604800,"secondsAfterSuccess":604800},"volumes":{"extraVolumeMounts":[],"extraVolumes":[]}}` | Set to false when only creating an importer with existing steps (see below). |
| importerStep.args | list | `[]` | REQUIRED (for Quarkus) |
| importerStep.command | list | `["sh","-c"]` | This defaults to "sh -c" if not set |
| importerStep.extractor | object | `{"enabled":false}` | Enable creation of extractor WorkflowTemplate |
| importerStep.image | object | `{"name":"","registry":"ghrc.io","repository":"","tag":""}` | Final image name is constructed as: registry/repository/name:tag |
| importerStep.image.name | string | `""` | Optional; defaults to "{{importerStep.name}}" |
| importerStep.image.registry | string | `"ghrc.io"` | Container registry to pull the importer-step image from |
| importerStep.image.repository | string | `""` | REQUIRED; Container repository. Use GitHub org and repository name, eg mobidrom/mobidp-importer-python |
| importerStep.image.tag | string | `""` | REQUIRED; Set the image tag to the version that should be used, e.g. 1.3.2 |
| importerStep.labels | object | `{}` | additional labels to merge with default app.kubernetes.io labels |
| importerStep.loader | object | `{"enabled":false}` | Enable creation of loader WorkflowTemplate |
| importerStep.name | string | `""` | REQUIRED; should match the importer-step name from the image, otherwise              'importerStep.image.name' needs to be overridden |
| importerStep.transformer | object | `{"enabled":false}` | Enable creation of transformer WorkflowTemplate |
| importerStep.ttlStrategy.secondsAfterFailure | int | `604800` | Optional; defaults to 604800 |
| importerStep.ttlStrategy.secondsAfterSuccess | int | `604800` | Optional; defaults to 604800 |
