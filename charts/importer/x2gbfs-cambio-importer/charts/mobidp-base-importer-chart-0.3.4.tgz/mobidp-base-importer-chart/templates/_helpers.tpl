
{{/********************/}}
{{/* GLOBAL VARIABLES */}}
{{/********************/}}

{{- define "global.imagePullSecrets" -}}
{{- $pullSecrets := list (dict "name" "mobidrom-registry") -}}
{{- if ((.Values.global).imagePullSecrets) -}}
    {{- $pullSecrets = .Values.global.imagePullSecrets -}}
{{- end -}}
{{ toYaml $pullSecrets }}
{{- end }}

{{- define "global.serviceAccountName" -}}
{{- if ((.Values.global).serviceAccountName) -}}
{{ .Values.global.serviceAccountName }}
{{- else -}}
wrkflw-run-tls-pods-sa
{{- end }}
{{- end }}

{{- define "global.namespace" -}}
{{ .Values.global.namespaceOverride | default .Release.Namespace }}
{{- end }}


{{/**************/}}
{{/* VALIDATION */}}
{{/**************/}}

{{- define "ensure-creation" -}}
{{- $importerStep := .Values.importerStep }}
{{- $valid := false}}
{{- if ($importerStep.extractor).enabled }}
{{- $valid = true }}
{{- else if ($importerStep.transformer).enabled }}
{{- $valid = true }}
{{- else if ($importerStep.loader).enabled }}
{{- $valid = true }}
{{- else if (.Values.importer).enabled }}
{{- $valid = true }}
{{- end }}
{{- if not $valid}}
{{ fail "Nothing to create. Enable the creation of one of the importer-steps or the importer." }}
{{- end }}
{{- end }}

{{/*
Validate that KStore table name length does not exceed 40 characters.
*/}}
{{- define "validateTableNameLength" -}}
  {{- if eq .name "IMPORT_TABLENAME" }}
    {{- if gt (len .value) 40 }}
      {{- fail (printf "❌ Validation failed for 'IMPORT_TABLENAME': value is too long. Max length is 40, but got %d." (len .value)) }}
    {{- end }}
  {{- end }}
{{- end }}


{{/**********************/}}
{{/* IMPORTER VARIABLES */}}
{{/**********************/}}

{{/* Generate a fullname for the importer (CronWorkflow) */}}
{{- define "importer.fullname" -}}
{{- required "The importer name must be provided at mobidp-base-importer-chart.importer.name" .Values.importer.name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* Collect and render labels for the CronWorkflow */}}
{{- define "importer.labels" -}}
app.kubernetes.io/name: {{ include "importer.fullname" . }}
app.kubernetes.io/component: mobidp-importer
app.kubernetes.io/manage-by: {{ .Release.Service }}
{{- $metadata := required "Importer metadata must be provided at mobidp-base-importer-chart.importer.metadata" .Values.importer.metadata }}
{{- $sourceMetadata := required "Data source must be provided at mobidp-base-importer-chart.importer.metadata.source" .Values.importer.metadata.source }}
importer.argo/data-source: {{ $sourceMetadata | quote }}
{{- $destinationMetadata := required "Data destination must be provided at mobidp-base-importer-chart.importer.metadata.destination" .Values.importer.metadata.destination }}
importer.argo/data-destination: {{ $destinationMetadata | quote }}
{{- $frequencyMetadata := required "Extract frequency must be provided at mobidp-base-importer-chart.importer.metadata.frequency" .Values.importer.metadata.frequency }}
importer.argo/frequency: {{ $frequencyMetadata | quote }}
{{- with .Values.importer.labels }}
{{ toYaml . | indent 2 }}
{{- end }}
{{- end -}}

{{/* Create ConfigMap for importer step */}}
{{- define "importer.config" -}}
{{- $globalConfigEnvs := .globalConfigEnvs -}}
{{- $importerStepName := .importerStep.name -}}
{{- $importerName := .importerName -}}
{{- $root := .root -}}
{{- if or .importerStep.config $globalConfigEnvs }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ printf "%s-%s-config" $importerName $importerStepName }}
  namespace: {{ include "global.namespace" $root }}
  labels:
    {{- include "importer.labels" $root | trim | nindent 4 }}
data:
  {{- range .importerStep.config | default list }}
  {{- include "validateTableNameLength" . }}
  {{ required ( printf "Name of the env variable in the load step '%s' must be provided." $importerStepName ) .name }}: {{ required ( printf "Value of the env variable '%s' in the load step '%s' must be provided." .name $importerStepName ) .value | quote }}
  {{- end }}
  {{- range $globalConfigEnvs | default list }}
  {{- include "validateTableNameLength" . }}
  {{ .name }}: {{ .value | quote }}
  {{- end }}

{{- end -}}
{{- end -}}

{{/* Create ExternalSecrets for importer step */}}
{{- define "importer.secrets" -}}
{{- $globalSecretEnvs := .globalSecretEnvs -}}
{{- $importerStepName := .importerStep.name -}}
{{- $importerName := .importerName -}}
{{- $root := .root -}}
{{- if or .importerStep.secrets $globalSecretEnvs }}
{{/* One ExternalSecret for all environment variables */}}
---
apiVersion: external-secrets.io/v1
kind: ExternalSecret
metadata:
  name: {{ printf "%s-%s-secret" $importerName $importerStepName }}
  namespace: {{ include "global.namespace" $root }}
  labels:
    {{- include "importer.labels" $root | trim | nindent 4 }}
spec:
  # --- Store Reference ---
  secretStoreRef:
    name: bitwarden-secretsstore
    kind: ClusterSecretStore
  # --- Data Mapping ---
  data:
    {{- range .importerStep.secrets | default list }}
    - secretKey: {{ required ( printf "Name of the secret variable in the extract step '%s' must be provided." $importerStepName ) .name }}
      remoteRef:
        key: {{ required ( printf "secretKeyRef for the '%s' secret stored in Bitwarden, must be provided in the extract step '%s'." .name $importerStepName ) .secretKeyRef }}
    {{- end }}
    {{- range $globalSecretEnvs | default list }}
    - secretKey: {{ .name }}
      remoteRef:
        key: {{ .secretKeyRef }}
    {{- end }}
{{- end }}

{{/* Dedicated Secret for a secret file */}}
{{- with .importerStep.secretFile }}
---
apiVersion: external-secrets.io/v1
kind: ExternalSecret
metadata:
  name: {{ printf "%s-%s-secret-file" $importerName $importerStepName }}
  namespace: {{ include "global.namespace" $root }}
  labels:
    {{- include "importer.labels" $root | trim | nindent 4 }}
spec:
  # --- Store Reference ---
  secretStoreRef:
    name: bitwarden-secretsstore
    kind: ClusterSecretStore
  # --- Data Mapping ---
  data:
    - secretKey: {{ required ( printf "Name of the secret file in the extract step '%s' must be provided." $importerStepName ) .name }}
      remoteRef:
        key: {{ required ( printf "secretKeyRef for the '%s' secret file stored in Bitwarden, must be provided in the extract step '%s'." .name $importerStepName ) .secretKeyRef }}
        decodingStrategy: Base64
{{- end }}
{{- end -}}


{{/***************************/}}
{{/* IMPORTER STEP VARIABLES */}}
{{/***************************/}}

{{/* Generate a fullname for the importer step (WorkflowTemplate) */}}
{{- define "importer-step.fullname" -}}
{{- required "The importer-step name must be provided at mobidp-base-importer-chart.importerStep.name" .Values.importerStep.name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* Collect and render labels for the WorkflowTemplate */}}
{{- define "importer-step.labels" -}}
app.kubernetes.io/name: {{ include "importer-step.fullname" . }}-importer
app.kubernetes.io/version: {{ .Values.importerStep.image.tag }}
app.kubernetes.io/component: mobidp-importer
app.kubernetes.io/manage-by: {{ .Release.Service }}
workflow-traffic-data-storage: "true"
{{- range .Values.importerStep.allowTrafficTo }}
{{ printf "workflow-traffic-%s: \"true\"" . }}
{{- end }}
{{- with .Values.importerStep.labels }}
{{ toYaml . }}
{{- end }}
{{- if ((.Values.global).labels) }}
{{- with .Values.global.labels }}
{{- toYaml . }}
{{- end }}
{{- end }}
{{- end -}}

{{/* Prepare container image name */}}
{{- define "importer-step.image" -}}
{{- $registry := default .Values.importerStep.image.registry "ghcr.io" }}
{{- $repository := required "The repository name must be provided at mobidp-base-importer-chart.importerStep.image.repository" .Values.importerStep.image.repository }}
{{- $name := .Values.importerStep.image.name | default ( include "importer-step.fullname" . )  }}
{{- $tag := required "A valid image tag must be provided at mobidp-base-importer-chart.importerStep.image.tag" .Values.importerStep.image.tag }}
{{- printf "%s/%s/%s:%s" $registry $repository $name $tag -}}
{{- end -}}

{{/* Set default time-to-live strategy for executed Workflows */}}
{{- define "importer-step.ttlStrategy.secondsAfterSuccess" -}}
{{- if ((.Values.importerStep.ttlStrategy).secondsAfterSuccess) -}}
{{ .Values.importerStep.ttlStrategy.secondsAfterSuccess }}
{{- else -}}
604800
{{- end -}}
{{- end }}

{{- define "importer-step.ttlStrategy.secondsAfterFailure" -}}
{{- if ((.Values.importerStep.ttlStrategy).secondsAfterFailure) -}}
{{ .Values.importerStep.ttlStrategy.secondsAfterFailure }}
{{- else -}}
604800
{{- end -}}
{{- end }}
